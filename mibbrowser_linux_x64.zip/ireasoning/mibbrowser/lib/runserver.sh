#!/bin/sh
DIRNAME=`dirname $0`
BROWSER_LIB=$DIRNAME
JEXE=$BROWSER_LIB/../jre/bin/java
if command -v $JEXE &>/dev/null
        then
            $JEXE  -Xmx1024m  -Duser.country=US -Duser.language=en -classpath $BROWSER_LIB/browser.jar  com.ireasoning.server.NetworkServer $*
        else
            echo "java command is not found. Please download and install java first. ( http://www.java.com/en/download/manual.jsp )"
fi

