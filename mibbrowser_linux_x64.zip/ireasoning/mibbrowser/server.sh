#!/bin/bash
"/Applications/MIB Browser.app/Contents/PlugIns/jdk1.8.0_241.jdk/Contents/Home/jre/bin/java" -Xmx768m -Djava.awt.headless=true -Duser.country=US -Duser.language=en -Dsun.java2d.d3d=false -Dsun.java2d.noddraw=true -jar "/Applications/MIB Browser.app/Contents/lib/server.jar" &



